
package dermatologyclinic11;

/**
 *
 * @author 
 */
public interface Laser { 

    /**
     * laser is something in common between body and face but it acts different with each one, that's why it is an interface
     */

    public abstract void doHairLaser();  
}

