
package dermatologyclinic11;

    /**
     * This abstract class has 2 Variables
     */
abstract class User {

    //***************************************<Variables>***************************************************   
 
    protected String name;
    protected String email;

    //***************************************<Methods>***************************************************
    /**
    *
    * Abstract method  
    */
    public abstract void printUserInfo();

}
